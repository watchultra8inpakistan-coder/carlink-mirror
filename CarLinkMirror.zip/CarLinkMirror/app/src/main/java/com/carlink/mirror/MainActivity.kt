package com.carlink.mirror

import android.Manifest
import android.app.Activity
import android.content.Intent
import android.media.projection.MediaProjectionManager
import android.os.Build
import android.os.Bundle
import android.provider.Settings
import android.widget.Button
import android.widget.LinearLayout
import android.widget.TextView
import java.net.Inet4Address
import java.net.NetworkInterface
import java.util.Random

class MainActivity : Activity() {
    private val pin = (1000 + Random().nextInt(9000)).toString()
    private lateinit var info: TextView

    override fun onCreate(b: Bundle?) {
        super.onCreate(b)
        if (Build.VERSION.SDK_INT >= 33) requestPermissions(arrayOf(Manifest.permission.POST_NOTIFICATIONS), 1)
        info = TextView(this).apply { textSize = 20f; setPadding(40, 80, 40, 40) }
        val touch = Button(this).apply {
            text = "1. Enable touch control"
            setOnClickListener { startActivity(Intent(Settings.ACTION_ACCESSIBILITY_SETTINGS)) }
        }
        val start = Button(this).apply {
            text = "2. Start mirroring"
            setOnClickListener {
                startActivityForResult(getSystemService(MediaProjectionManager::class.java).createScreenCaptureIntent(), 1)
            }
        }
        val stop = Button(this).apply {
            text = "Stop"
            setOnClickListener { stopService(Intent(this@MainActivity, MirrorService::class.java)) }
        }
        setContentView(LinearLayout(this).apply {
            orientation = LinearLayout.VERTICAL
            addView(info); addView(touch); addView(start); addView(stop)
        })
    }

    override fun onResume() {
        super.onResume()
        val ips = NetworkInterface.getNetworkInterfaces().toList()
            .flatMap { it.inetAddresses.toList() }
            .filter { !it.isLoopbackAddress && it is Inet4Address }
            .map { it.hostAddress }
        info.text = "PIN: $pin\n\nOn the car browser open one of:\n" +
            ips.joinToString("\n") { "http://$it:8080" } +
            "\n\nTouch control: " + (if (TouchService.inst != null) "ON" else "OFF (turn on CarLink Mirror in Accessibility)") +
            "\n\nFirst connect the car to this phone's hotspot (or the same Wi-Fi)."
    }

    override fun onActivityResult(req: Int, res: Int, data: Intent?) {
        if (req == 1 && res == RESULT_OK && data != null) {
            startForegroundService(
                Intent(this, MirrorService::class.java)
                    .putExtra("code", res).putExtra("data", data).putExtra("pin", pin)
            )
        }
    }
}
