package com.carlink.mirror

import android.app.Notification
import android.app.NotificationChannel
import android.app.NotificationManager
import android.app.Service
import android.content.Intent
import android.content.pm.ServiceInfo
import android.graphics.Bitmap
import android.graphics.PixelFormat
import android.hardware.display.DisplayManager
import android.hardware.display.VirtualDisplay
import android.media.ImageReader
import android.media.projection.MediaProjection
import android.media.projection.MediaProjectionManager
import android.os.Build
import android.os.Handler
import android.os.HandlerThread
import android.os.IBinder
import android.os.SystemClock
import android.util.DisplayMetrics
import java.io.ByteArrayOutputStream
import java.net.ServerSocket
import java.net.Socket
import kotlin.concurrent.thread

class MirrorService : Service() {
    @Volatile private var frame: ByteArray? = null
    @Volatile private var seq = 0L
    private var server: ServerSocket? = null
    private var proj: MediaProjection? = null
    private var vd: VirtualDisplay? = null
    private var reader: ImageReader? = null
    private var pin = "0000"
    private var rw = 1080f
    private var rh = 1920f
    private val ht = HandlerThread("capture")

    override fun onBind(i: Intent?): IBinder? = null

    override fun onStartCommand(i: Intent?, f: Int, s: Int): Int {
        if (i == null) { stopSelf(); return START_NOT_STICKY }
        pin = i.getStringExtra("pin") ?: "0000"
        val nm = getSystemService(NotificationManager::class.java)
        nm.createNotificationChannel(NotificationChannel("m", "Mirroring", NotificationManager.IMPORTANCE_LOW))
        val n = Notification.Builder(this, "m").setContentTitle("CarLink is mirroring your screen")
            .setSmallIcon(android.R.drawable.ic_menu_view).build()
        if (Build.VERSION.SDK_INT >= 29) startForeground(1, n, ServiceInfo.FOREGROUND_SERVICE_TYPE_MEDIA_PROJECTION)
        else startForeground(1, n)

        val data = i.getParcelableExtra<Intent>("data")!!
        proj = getSystemService(MediaProjectionManager::class.java).getMediaProjection(i.getIntExtra("code", 0), data)
        ht.start()
        val h = Handler(ht.looper)
        proj!!.registerCallback(object : MediaProjection.Callback() { override fun onStop() { stopSelf() } }, h)

        val dm = DisplayMetrics()
        getSystemService(DisplayManager::class.java).getDisplay(0).getRealMetrics(dm)
        rw = dm.widthPixels.toFloat(); rh = dm.heightPixels.toFloat()
        val w = 720
        val hh = dm.heightPixels * w / dm.widthPixels
        reader = ImageReader.newInstance(w, hh, PixelFormat.RGBA_8888, 2)
        vd = proj!!.createVirtualDisplay("mirror", w, hh, dm.densityDpi,
            DisplayManager.VIRTUAL_DISPLAY_FLAG_AUTO_MIRROR, reader!!.surface, null, h)
        var last = 0L
        reader!!.setOnImageAvailableListener({ r ->
            val img = r.acquireLatestImage() ?: return@setOnImageAvailableListener
            try {
                val now = SystemClock.uptimeMillis()
                if (now - last < 66) return@setOnImageAvailableListener
                last = now
                val p = img.planes[0]
                val bmp = Bitmap.createBitmap(p.rowStride / p.pixelStride, img.height, Bitmap.Config.ARGB_8888)
                bmp.copyPixelsFromBuffer(p.buffer)
                val out = ByteArrayOutputStream()
                Bitmap.createBitmap(bmp, 0, 0, img.width, img.height).compress(Bitmap.CompressFormat.JPEG, 60, out)
                frame = out.toByteArray(); seq++
            } finally { img.close() }
        }, h)

        thread {
            try {
                server = ServerSocket(8080)
                while (!server!!.isClosed) {
                    val c = server!!.accept()
                    thread { try { handle(c) } catch (_: Exception) { } finally { c.close() } }
                }
            } catch (_: Exception) { }
        }
        return START_NOT_STICKY
    }

    private fun handle(c: Socket) {
        val rd = c.getInputStream().bufferedReader()
        val line = rd.readLine() ?: return
        while (true) { val l = rd.readLine(); if (l.isNullOrEmpty()) break }
        val path = line.split(" ").getOrElse(1) { "/" }
        val out = c.getOutputStream()
        val q = path.substringAfter("?", "").split("&").filter { it.contains("=") }
            .associate { it.substringBefore("=") to it.substringAfter("=") }
        if (path.startsWith("/stream")) {
            if (q["pin"] != pin) { out.write("HTTP/1.1 403 Forbidden\r\nContent-Length: 0\r\n\r\n".toByteArray()); return }
            out.write("HTTP/1.1 200 OK\r\nContent-Type: multipart/x-mixed-replace; boundary=f\r\nCache-Control: no-cache\r\n\r\n".toByteArray())
            var s = -1L
            while (!c.isClosed) {
                val f = frame
                if (f != null && seq != s) {
                    s = seq
                    out.write("--f\r\nContent-Type: image/jpeg\r\nContent-Length: ${f.size}\r\n\r\n".toByteArray())
                    out.write(f); out.write("\r\n".toByteArray()); out.flush()
                } else Thread.sleep(20)
            }
        } else if (path.startsWith("/touch")) {
            val ok = q["pin"] == pin
            if (ok) touch(q)
            out.write("HTTP/1.1 ${if (ok) 204 else 403} X\r\nContent-Length: 0\r\n\r\n".toByteArray())
        } else {
            val b = assets.open("index.html").readBytes()
            out.write("HTTP/1.1 200 OK\r\nContent-Type: text/html; charset=utf-8\r\nContent-Length: ${b.size}\r\n\r\n".toByteArray())
            out.write(b); out.flush()
        }
    }

    private fun touch(q: Map<String, String>) {
        val t = TouchService.inst ?: return
        fun v(k: String, m: Float) = ((q[k]?.toFloatOrNull() ?: 0f).coerceIn(0f, 1f)) * m
        when (q["a"]) {
            "tap" -> t.gesture(v("x", rw), v("y", rh), v("x", rw), v("y", rh), 50)
            "swipe" -> t.gesture(v("x1", rw), v("y1", rh), v("x2", rw), v("y2", rh), q["d"]?.toLongOrNull() ?: 250)
            "key" -> t.key(q["k"] ?: "")
        }
    }

    override fun onDestroy() {
        try { server?.close() } catch (_: Exception) { }
        vd?.release(); reader?.close(); proj?.stop(); ht.quitSafely()
        super.onDestroy()
    }
}
