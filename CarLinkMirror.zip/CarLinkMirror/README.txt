CarLink Mirror (with touch control)
1. Open this folder in Android Studio (Hedgehog or newer). Let Gradle sync, then Run on your phone.
2. In the app tap "1. Enable touch control", find "CarLink Mirror" in Accessibility and turn it on.
   (If Android says it is restricted: App info > three dots > Allow restricted settings.)
3. Turn on the phone hotspot and connect the car to it.
4. Tap "2. Start mirroring" and allow screen capture. Note the PIN and the http://IP:8080 address.
5. Open that address in the car's Chrome, enter the PIN, tap Phone screen in the left rail.

NO ANDROID STUDIO (e.g. Chromebook): upload this folder's contents to a free GitHub repo.
The included .github/workflows/build.yml builds the APK. Open the Actions tab, run "Build APK",
download the CarLinkMirror-apk artifact, send app-debug.apk to your phone and install it.
